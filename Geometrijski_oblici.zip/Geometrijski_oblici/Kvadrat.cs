﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometrijski_oblici
{
  public class Kvadrat:Oblik
    {
        public Kvadrat(int dimenzija):
            base(dimenzija) 
        {

        }
        public override void Crtaj()
        {
            for (int i = 0; i < Dimenzija; i++)
            {
                for (int j = 0; j < Dimenzija; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }
        }
    }
}
