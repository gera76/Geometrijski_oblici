﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometrijski_oblici
{
    public class Pravugaonik:Oblik
    {
        public int sirina { get;private set; }
        public Pravugaonik(int duzina,int sirina):
            base(duzina)
        {
            this.sirina = sirina;
        }
        public override void Crtaj()
        {
           for(int i = 0; i < Dimenzija; i++)
            {
                for(int j=0; j < sirina; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }
        }
    }
}
