﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometrijski_oblici
{
    public class JednakokrakiPravougliTrougao:Oblik
    {
        public JednakokrakiPravougliTrougao(int dimenzija) :
          base (dimenzija)
            {
            }
        public override void Crtaj()
        {
            for (int i = Dimenzija; i > 0; i--) //-> postepeno smanjivanje
            //for (int i = 0; i <= Dimenzija; i++)  -> postepeno povecavanje
            {
                for (int j = 0; j < i; j++)
                {
                    Console.Write("* ");
                }
                Console.WriteLine();
            }
        }
    }
}
