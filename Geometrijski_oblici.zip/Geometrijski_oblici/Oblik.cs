﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometrijski_oblici
{
    public abstract class Oblik
    {
        public int Dimenzija { get;private set;}
        public Oblik(int dimenzija)
        {
            this.Dimenzija = dimenzija;
        }
        public abstract void Crtaj();
    }
}
