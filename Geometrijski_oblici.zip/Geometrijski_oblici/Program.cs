﻿// See https://aka.ms/new-console-template for more information

using Geometrijski_oblici;

Console.Write("unesite dimenziju trougla : ");
int t=int.Parse(Console.ReadLine());

Console.Write("unesite dimenziju kvadrata : ");
int k=int.Parse(Console.ReadLine());

Console.Write("Unesite duzinu pravougaonika: ");
int d = int.Parse(Console.ReadLine());

Console.Write("Unesite širinu pravougaonika: ");
int s = int.Parse(Console.ReadLine());



List<Oblik> Geometrijski_oblici = new List<Oblik> 
{
     new JednakokrakiPravougliTrougao(t),
     new Kvadrat(k),
     new Pravugaonik(d,s)
};



foreach (var oblik in Geometrijski_oblici)
{
    Console.WriteLine($"Crtam {oblik.GetType().Name}:");
    oblik.Crtaj(); 
    Console.WriteLine();
}




